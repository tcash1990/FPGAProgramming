lappend auto_path "C:/lscc/diamond/3.13/data/script"
package require simulation_generation
set ::bali::simulation::Para(DEVICEFAMILYNAME) {MachXO3D}
set ::bali::simulation::Para(PROJECT) {HW9}
set ::bali::simulation::Para(PROJECTPATH) {C:/LatticeProjects/HW9}
set ::bali::simulation::Para(FILELIST) {"C:/LatticeProjects/HW9/Bus_Interface_Common.vhd" "C:/LatticeProjects/HW9/Generic_Components.vhd" "C:/LatticeProjects/HW9/SPI_ADC_Int.vhd" "C:/LatticeProjects/HW9/LED_Cntrl.vhd" "C:/LatticeProjects/HW9/UART_Usr_Int.vhd" "C:/LatticeProjects/HW9/DSPRAM.vhd" "C:/LatticeProjects/HW9/Bus_Master.vhd" "C:/LatticeProjects/HW9/PLLSerial.vhd" "C:/LatticeProjects/HW9/Bus_Interface_Top.vhd" "C:/LatticeProjects/HW9/ADC/Bus_Interface_tb.vhd" }
set ::bali::simulation::Para(GLBINCLIST) {}
set ::bali::simulation::Para(INCLIST) {"none" "none" "none" "none" "none" "none" "none" "none" "none" "none"}
set ::bali::simulation::Para(WORKLIBLIST) {"work" "work" "work" "work" "work" "work" "work" "work" "work" "" }
set ::bali::simulation::Para(COMPLIST) {"VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" "VHDL" }
set ::bali::simulation::Para(LANGSTDLIST) {"" "" "" "" "" "" "" "" "" "" }
set ::bali::simulation::Para(SIMLIBLIST) {pmi_work ovi_machxo3d}
set ::bali::simulation::Para(MACROLIST) {}
set ::bali::simulation::Para(SIMULATIONTOPMODULE) {Bus_Interface_TestBench}
set ::bali::simulation::Para(SIMULATIONINSTANCE) {}
set ::bali::simulation::Para(LANGUAGE) {VHDL}
set ::bali::simulation::Para(SDFPATH)  {}
set ::bali::simulation::Para(INSTALLATIONPATH) {C:/lscc/diamond/3.13}
set ::bali::simulation::Para(ADDTOPLEVELSIGNALSTOWAVEFORM)  {1}
set ::bali::simulation::Para(RUNSIMULATION)  {1}
set ::bali::simulation::Para(HDLPARAMETERS) {}
set ::bali::simulation::Para(POJO2LIBREFRESH)    {}
set ::bali::simulation::Para(POJO2MODELSIMLIB)   {}
::bali::simulation::ModelSim_Run
