----------------------------------------------------------------------------------
-- Company:  University of Arkansas (NCREPT)
-- Engineer: Tyler Cash
-- 
-- Create Date:			13Apr2026
-- Last Updated:		22Jan2026
-- Design Name: 		Bus Interface w/ UART & PWM & SPI
-- Module Name: 		SPI_ADC_INT - Behavioral
-- Target Devices: 		LCMXO3D-9400HC-6BG256C (MachXO3D_BreakoutBrd)
-- Tool versions: 		Lattice Diamond_x64 Build  3.12.0.240.2
-- Description: 
-- This Project was developed to demonstrate a system-level design which incorperates shared registers and communications.
-- You may use various Serial Interface programs to communicate with this including the old version of X-CTU (Version 5.2.8.6), 
-- Termite, HypterTerminal, or the Custom LabVIEW Interface created for this project (LabVIEW-CommEx_Bus_Interface_PWM_v1.0a_16Apr2021).
-- A key to remember is that you will need to create packets in Hex-Mode not the standard ASCII-Mode.
-- Four individual on-board LEDs will be controlled via a simple PWM interface.
-- Each PWM will have its duty cycle set via system registers which may be modified via the serial interface.
-- A Testbench for this project was created and demostrates base functionality.
--
---- PinOut:
-- Signal			CPLD_Pin	Description
-- LED_1			H11			LED1			(Output)	[Onboard LED]
-- LED_2			J13			LED2			(Output)	[Onboard LED]	
-- LED_3			J11			LED3			(Output)	[Onboard LED]
-- LED_4			L12			LED4			(Output)	[Onboard LED]
-- LED_5			K11			LED5			(Output)	[Onboard LED]
-- LED_6			L13			LED6			(Output)	[Onboard LED]
-- LED_7			N15			LED7			(Output)	[Onboard LED]
-- LED_8			P16			LED8			(Output)	[Onboard LED]
-- PWM_Test_Out		N14			PWM Test		(Output)	
-- SCI_TX			C11			Serial-TX		(Output)	[USB Serial Port on Breakout Board]
-- SCI_RX			A11			Serial-RX		(Input)		[USB Serial Port on Breakout Board]
-- ADC_SCLK 		E6
-- ADC_DIN 			C5
-- ADC_CSn 			C4
-- ADC_DOUT			D6
-- DSP_G1			C12
-- DSP_G2			E11

--
---- Register and Memory Map Information:
-- This section describes the Memory Map used in this project.
-- This design contains a SPRAM Module which is 16 bits wide and 1024 entries deep.
-- Register addresses are from X"0000" to X"03FF".
-- All registers are 16-bits wide.
-- The SPRAM Module is located in the Bus_Master portion of the code.
-- This RAM Module may be accessed externally using Serial Port interface.
-- Reserved for future use.
-- X"0300" - X"03FF"
--
-- LED Configuration Values-
-- Range is X"0100" - X"010A"
--
-- SPI ADC Measurement Values-
-- Range is X"0200" - X"020A"
--
-- Register Map is found as constants in Bus_Interface_Common and shared with all submodules of this program.
--
---- Serial Settings
-- Baud: 			9600
-- Flow Control: 	None
-- Data Bits:		8
-- Parity: 			None
-- Stop Bits:		1
--
-- 
--
---- Serial Communications:
-- In the project we will construct packets to facilitate serial communication between the device and a computer. 
-- Using packets we can implement operational commands and check sums which allow for easily implementing a user GUI. 
-- You may use various Serial Interface programs to communicate with this including the old version of X-CTU (Version 5.2.8.6), 
-- Termite, HypterTerminal, or the Custom LabVIEW Interface created for this project (LabVIEW-CommEx_Bus_Interface_PWM_v1.0a_16Apr2021)
-- A key to remember is that you will need to create packets in Hex-Mode not the standard ASCII-Mode.
-- All packets will begin with a Start Delimiter (0x7E) and end with a CheckSum. 
-- The CheckSum is calculated by adding up all the bytes of the packet between the packet length and the checksum then 
-- subtracting the sum from 0xFF. 
-- We will implement two types of packets for our use. 
-- Register Write Command Packet (Used to update registers internal to the CPLD)
-- Register Read Command Packet (Used to read registers internal to the CPLD)
--
---Serial Write Packet (OP_ID = 0x0A)
-- The Register Write Command Packet is used to update registers internal to the CPLD. 
-- The following example breaks down a write request packet. 
-- The packet below writes 7 16-bit registers starting at register 0x0100; Values listed below. 
-- PWM_Enable     => 0x0001 (1=Enable; 0=Disable) 
-- LED_BlinkFreq  => 0xBFFF [75%]   (BFFF/FFFF) (%) 
-- LED_OnTime     => 0x6000 [50%]   (6000/BFFF) (%) 
-- LED1_Intensity => 0x2000 [12.5%] (2000/FFFF) (%)
-- LED2_Intensity => 0x4000 [25%]   (4000/FFFF) (%)
-- LED3_Intensity => 0x8000 [50%]   (8000/FFFF) (%)
-- LED4_Intensity => 0xFFFF [100%]  (FFFF/FFFF) (%)
--
-- Start Delimiter| Pkt Len |Op ID| Register_Cnt |Start Address   |Register Data (16bit x Register_Cnt) | ChkSum
-- 0x7E           | 0x12    |0x0A |0x07          |0x0100          |0x0001BFFF6000200040008000FFFF       | 0xF0
-- 0x7E120A0701000001BFFF6000200040008000FFFFF0 results in all LEDs being set to the above parameters.
-- 0x7E120A0701000001BFFF60000000000000000000CE results in all LED Intensities being set to 0%. 
--
--- Serial Read Packet (OP_ID = 0x0F)
-- The Register Read Command Packet is used to read registers internal to the CPLD. 
-- The following example breaks down a read request packet. 
-- The packet below reads 16 16-bit registers starting at register 0x0100. 
--  Start Delimiter| Pkt Len |Op ID| Register_Cnt |Start Address | ChkSum
--  0x7E           | 0x04    |0x0F |0x10          |0x0100        | 0xDF
-- 0x7E040F100100DF 
--
-- The above command results in a write command being sent from the CPLD which contains data from 16 16-bit registers starting at address 0x0100. 
-- An example response from the CPLD is shown below: 
-- 0x7E240A1001000001BFFF6000200040008000FFFF000000000000000000000000000000000000E7 
--  Start Delimiter| Pkt Len |Op ID| Register_Cnt |Start Address |Register Data (16bit x Register_Cnt)                               | ChkSum
--  0x7E           | 0x24    |0x0A |0x10          |0x0100        |0x0001BFFF6000200040008000FFFF000000000000000000000000000000000000 | 0xE7
-- 
--
--
--
--
-- Revisions:--
--
---- Revision 2.2d --- Updated Optimization for Strategy1 to "Timing" in "Synthesize-LSE-Optimization Goal" from "Area".
-- Solved the issue of ADC reading only once on power up. Also, included "Map Design" Option in Process Synthesis. (11Jan2023)
--
---- Revision 2.2c --- Updated back to SPRAM Module for testbench compatibility.
-- Updated on 21Apr2021 to include correct pin numbers in documentation and four PWM modules designed in class.
-- Added design files and drawings for PWMs to Supplemental Folder.
--
---- Revision 2.2b --- Updated back to SPRAM Module for testbench compatibility.
-- Updated on 8Apr2021 so it is compatible with the testbench, will update again in the future back to DPRAM.
--
---- Revision 2.2a --- Updated from SPRAM to DPRAM Module
-- Updated on 27Mar2021 to use a DPRAM module to take advantage of EBRs and maintain compatibility with other programs.
--
---- Revision 2.1a -
-- Updated for Git Implementation
--
---- Revision 2.0a - 
-- Updated for MachXO3D and so it could serve as an example for the "Programming for Power Electronics" Class.
-- Testbed updated to allow for Read and Write Command Verification
-- Minor Updates to documentation and PWMs.
-- Testbench updated to allow for Read and Write Command Verification
--
---- Revision 1.1a - 
-- Updated to use Protocols based on Zigbee Implementation
--
-- Revision 1.0b - 
-- Updated to use UCB instead of Evaluation Board
--
-- Revision 0.01 - 
-- File Created; Basic\Classical Operation Implemented
--
--
-- Additional Comments: 
-- 
--
----------------------------------------------------------------------------------

Library IEEE;
use IEEE.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;


entity SPI_ROM is
	port ( rst, clk, D_Sel: in std_logic;
		data: out std_logic_vector(15 downto 0));
end SPI_ROM;

architecture behavior of SPI_ROM is

begin
	SPI_ROM_behav: process
	begin

			-- X"831F";		 -- Command to read ADC Channel 0
			-- X"FFDF";		 -- Command to read All ADC Channels Continuously
			-- X"E3DF";		 -- Command to read ADC Channel 0 Continuously
			-- X"E7DF";		 -- Command to read ADC Channel 1+2 Continuously
			-- X"FFDF";		 -- Command to read All ADC Channels Continuously
			-- X"871F";		 -- Command to read ADC Channel 1
			-- X"8B1F";		 -- Command to read ADC Channel 2
			-- X"8F1F";		 -- Command to read ADC Channel 3
			-- X"931F";		 -- Command to read ADC Channel 4
			-- X"971F";		 -- Command to read ADC Channel 5
			-- X"9B1F";		 -- Command to read ADC Channel 6
			-- X"9F1F";		 -- Command to read ADC Channel 7

			wait until clk'event and clk = '1';
			if rst='0' then
				data <= (Others =>'0');
			else
				if D_Sel = '0' then
					data <= X"FFDF";
				else
					data <= X"FFFF";
				end if;
			end if;
			
	end process;
end behavior;
--------------------------------------END ROM for ADC Commands ---------------------------------------

library IEEE;
use IEEE.std_logic_1164.ALL;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use ieee.numeric_std.All;

library work;
use work.Bus_Interface_Common.all;

entity ADC_Int is
	Port ( 	clk		:	in		STD_LOGIC;
			rst	 	:	in 		STD_LOGIC;
			Data 	:	INOUT 	std_logic_vector(15 downto 0);
			Addr	:	out		std_logic_vector(15 downto 0);
			Xrqst	:	out		std_logic;
			XDat	:	in		std_logic;
			YDat	:	out		std_logic;
			BusRqst	:	out		std_logic;
			BusCtrl	:	in		std_logic;
			SPI_Sclk:	INOUT	std_logic;
			SPI_Din	:	INOUT	std_logic;
			SPI_CSn	:	out		std_logic;
			SPI_Dout:	in		std_logic
			);
end ADC_Int;

architecture Behavioral of ADC_Int is

	----Constants
	constant Chan 			: 	std_logic_vector(2 downto 0):= "111"; 			-- Set maximum sampled ADC
	--constant Delay 		: 	std_logic_vector(15 downto 0) := X"07FE";			-- Initial ADC delay for Sync
	constant Delay			:	std_logic_vector (15 downto 0):= X"00BA";			-- Initial ADC delay for Sync
	constant Offset_Chan	:	std_logic_vector(7 downto 0):= X"07";				-- Delay between samples
	constant Offset_Set		:	std_logic_vector(7 downto 0):= X"1E";				-- This is the delay between samples
	constant Sample_Size	:	integer := 2;										-- Sample Size for ADC
	
	type state_type is (S0, S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15, S16, S17, S18); 
	signal CS_ADC_Ctrl, NS_ADC_Ctrl, CS_Bus_Ctrl, NS_Bus_Ctrl: state_type:= S0;
	
	signal SPI_Cnt_INC, SPI_Cnt_rst, Prg_Cnt_INC, Prg_Cnt_rst, Setup_Cnt_INC, Setup_Cnt_rst	:std_logic:='0';
	signal Prg_Cnt_Out, Setup_Cnt_Out : std_logic_vector (7 downto 0):= (others => '0');
	signal SPI_Cnt_Out: std_logic_vector (15 downto 0):= (others => '0');
	
	Signal SPI_ROM1_D_SEL	: std_logic:= '0';
	--signal SPI_ROM1_addr: std_logic_vector(2 downto 0);
	signal SPI_ROM1_data	: std_logic_vector(15 downto 0):= (others => '0');
	
	signal SPI_PS_ld_D, SPI_PS_sh_D, SPI_PS_rst : std_logic:= '0';
	--signal SPI_SP1_Data_In : std_logic_vector (15 downto 0);
	
	signal SPI_SP_ld_D, SPI_SP_rst: STD_LOGIC:='0';
	signal SPI_SP1_Data_Out, SPI_SP2_Data_Out :std_logic_vector(15 downto 0):= (others => '0');
	 
	
	signal SPI_Dout1_Sync : std_logic:='0';
	signal SPI_Dout2_Sync : std_logic:='0';
	  
	
	--Signals for ADC Memory
	type Memory is array(15 downto 0) of std_logic_vector (15 downto 0);
	signal ADC_Mem: Memory;
	signal ADC_wea:STD_LOGIC:='0';
	signal ADC_Mem_Ave: Memory;
	signal ADC_Ave_Ld, ADC_Ave_En : std_logic:='0';
	signal ADC_Mem_Temp: Memory;
	signal ADC_Temp_rst:std_logic:= '0';
	signal Ave_Cnt_INC, Ave_Cnt_rst : std_logic:='0';
	signal Ave_Cnt_Out : std_logic_vector(7 downto 0):= (others => '0');
	signal ADC_Mem_Ave_M1, ADC_Mem_Ave_M2: Memory;
	
	
	--Declare signals for Bus Interface
	signal Bus_Int1_WE, Bus_Int1_RE, Bus_Int1_Busy: STD_LOGIC:= '0';
	signal Bus_Int1_DataIn, Bus_Int1_DataOut, Bus_Int1_AddrIn: std_logic_vector(15 downto 0):= (others => '0');
	signal Bus_Cnt_rst, Bus_Cnt_Inc: STD_LOGIC:= '0';
	Signal Bus_Cnt_Out: std_logic_vector(15 downto 0):= (others => '0');
	signal Mem_Addr_Cnt_rst, Mem_Addr_Cnt_INC: STD_LOGIC:= '0';
	signal Mem_Addr_Cnt_Out: std_logic_vector(7 downto 0):= (others => '0');
	
	
	
	--For CLock Divider
	signal clk_temp2 : std_logic_vector(3 downto 0):= (others => '0');
	signal clk_SPI :	std_logic := '0';
	
	--For SPI Setup Loop Counter
	signal SPI_CNT_Loop_INC, SPI_CNT_Loop_rst :std_logic:='0';
	signal SPI_CNT_Loop_Out : std_logic_vector(15 downto 0):= (others => '0');
	
	
	
	--declare STD_Counter component
	component Std_Counter is
	generic
	(
		width : integer	--width of Counter
	);
	port(INC,rst,clk: in std_logic;
		 Count: out std_logic_vector(Width-1 downto 0));
	end component;
	
	 
	
	-- declare SPI_ROM component
	component SPI_ROM is
		Port ( 	clk 	: in std_logic;
				rst 	: in std_logic;
				D_Sel 	: in std_logic;
				data	: out std_logic_vector(15 downto 0)
				);
	end component;
		
	-- declare Sreg_PS_16 component
	component Sreg_PS_16 is
		Port(	clk		: in std_logic;
				rst		: in std_logic;
				ld_D	: in std_logic;
				sh_D	: in std_logic;
				Data_In	: in std_logic_vector(15 downto 0);
				Data_Out: out std_logic
				);
	end component;
	
	-- declare Sreg_SP_16 component
	component Sreg_SP_16 is
		Port(	clk		: in std_logic;
				rst		: in std_logic;
				ld_D	: in std_logic;
				Data_In : in std_logic;
				Data_Out: out std_logic_vector(15 downto 0));
	end component;
	
	--declare Bus Interface
	component Bus_Int
		Port(
			 clk	:	IN 		std_logic;
			 rst	:	IN 		std_logic;
			 DataIn	:	IN 		std_logic_vector(15 downto 0);
			 DataOut:	OUT 	std_logic_vector(15 downto 0);
			 AddrIn :	IN 		std_logic_vector(15 downto 0);
			 WE		:	IN 		std_logic;
			 RE 	: 	IN 		std_logic;
			 Busy	:	OUT 	std_logic;
			 Data	:	INOUT	std_logic_vector(15 downto 0);
			 Addr	:	OUT		std_logic_vector(15 downto 0);
			 Xrqst	:	OUT		std_logic;
			 XDat	: 	IN		std_logic;
			 YDat	:	OUT		std_logic;
			 BusRqst:	OUT		std_logic;
			 BusCtrl:	IN		std_logic
		);
	END component;
	
	
begin

	--Connect Signals
	SPI_sclk <= clk_SPI;
	--SPI_Din<=SPI_PS_Data_Out;
	
	--instantiate SPI_Cnt_16
	SPI_Cnt: STD_Counter
	generic map
	(
		Width => 16
	)
	port map(
			clk => clk_SPI,
			rst => SPI_Cnt_rst,
			INC => SPI_Cnt_Inc,
			Count => SPI_Cnt_Out);
			
	
	--instantiate Prg_Cnt_8
	Prg_Cnt: STD_Counter
	generic map
	(
		Width => 8
	)
	port map(
			clk => clk_SPI,
			rst => Prg_Cnt_rst,
			INC => Prg_Cnt_INC,
			Count => Prg_Cnt_Out);
	
	--instantiate Setup_Cnt_8
	Setup_Cnt: STD_Counter
	generic map
	(
		Width => 8
	)
	port map(
			clk => clk_SPI,
			rst => Setup_Cnt_rst,
			INC => Setup_Cnt_INC,
			Count => Setup_Cnt_Out);
	
	--instantiate Ave_Cnt_8
	Ave_Cnt: STD_Counter
	generic map
	(
		Width => 8
	)
	port map(
			clk => clk_SPI,
			rst => Ave_Cnt_rst,
			INC => Ave_Cnt_INC,
			Count => Ave_Cnt_Out);
	
	--instantiate Mem_Cnt
	Mem_Cnt: STD_Counter
	generic map
	(
		Width => 8
	)
	port map(
		clk => clk,
		rst => Mem_Addr_Cnt_rst,
		INC => Mem_Addr_Cnt_INC,
		Count => Mem_Addr_Cnt_Out);
	
	--instantiate SPI_ROM1_addr
	SPI_ROM1: SPI_ROM port map (
			clk => clk_SPI,
			rst => rst,
			D_Sel => SPI_ROM1_D_SEL,
			data => SPI_ROM1_data);
			
	--instantiate SPI_PS 
	SPI_PS: Sreg_PS_16 port map(
			clk => clk_SPI,
			rst => SPI_PS_rst,
			ld_D => SPI_PS_ld_D,
			sh_D => SPI_PS_sh_D,
			--Data_In => SPI_PS_Data_In,
			Data_In => SPI_ROM1_data,
			Data_Out => SPI_Din);
			
	--instantiate SPI_SP for ADC1
	SPI_SP: sreg_SP_16 port map(
			clk => clk_SPI,
			rst => SPI_SP_rst,
			ld_D => SPI_SP_ld_D,
			Data_In => SPI_Dout1_Sync,
			Data_Out => SPI_SP1_Data_Out);
	
	--Instantiate Bus Interface
	Bus_Int1: Bus_Int PORT map(
			clk => clk,
			rst => rst,
			DataIn => Bus_Int1_DataIn,
			DataOut=> Bus_Int1_DataOut,
			AddrIn => Bus_Int1_AddrIn,
			WE => Bus_Int1_WE,
			RE => Bus_Int1_RE,
			Busy => Bus_Int1_Busy,
			Data => Data,
			Addr => Addr,
			Xrqst => Xrqst,
			XDat => XDat,
			YDat => YDat,
			BusRqst => BusRqst,
			BusCtrl => BusCtrl
		);
		
	--Instantiate Bus_Cnt_16
	Bus_Cnt: STD_Counter
	generic map
	(
		Width => 16
	)
	port map(
			clk => clk,
			rst => Bus_Cnt_rst,
			INC => Bus_Cnt_Inc,
			Count => Bus_Cnt_Out);
			
	--instantiate Bus_Cnt_16
	SPI_Loop_Cnt: Std_Counter
	generic map
	(
		Width => 16
	)
	port map(
			clk => clk,
			rst => SPI_CNT_Loop_rst,
			INC => SPI_CNT_Loop_INC,
			Count => SPI_CNT_Loop_Out);
			
	
	
	----Process for storing sampled data into ADC Memory
	ADC_Mem_W: Process
	begin
		wait until clk_SPI'event and clk_SPI = '1';
		if rst = '0' then
			ADC_Mem(0) <= (others => '0');
			ADC_Mem(1) <= (others => '0');
			ADC_Mem(2) <= (others => '0');
			ADC_Mem(3) <= (others => '0');
			ADC_Mem(4) <= (others => '0');
			ADC_Mem(5) <= (others => '0');
			ADC_Mem(6) <= (others => '0');
			ADC_Mem(7) <= (others => '0');
			ADC_Mem(8) <= (others => '0');
			ADC_Mem(9) <= (others => '0');
			ADC_Mem(10) <= (others => '0');
			ADC_Mem(11) <= (others => '0');
			ADC_Mem(12) <= (others => '0');
			ADC_Mem(13) <= (others => '0');
			ADC_Mem(14) <= (others => '0');
			ADC_Mem(15) <= (others => '0');
			
		elsif ADC_wea = '1' then
			if SPI_SP1_Data_Out(14 downto 12) = "000" then ADC_Mem(0)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "001" then ADC_Mem(1)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "010" then ADC_Mem(2)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "011" then ADC_Mem(3)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "100" then ADC_Mem(4)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "101" then ADC_Mem(5)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "110" then ADC_Mem(6)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
			if SPI_SP1_Data_Out(14 downto 12) = "111" then ADC_Mem(7)		<= X"0" & SPI_SP1_Data_Out(11 downto 0); end if;
	
	
		end if;
	end Process;
	----End Registers
		
	----Process for averaging sampled data
	Sample_Ave: Process
	begin
		wait until clk_SPI'event and clk_SPI = '1';
		if (rst = '0' or ADC_Temp_rst = '0') then
			ADC_Mem_Temp(0) <= (others => '0');
			ADC_Mem_Temp(1) <= (others => '0');
			ADC_Mem_Temp(2) <= (others => '0');
			ADC_Mem_Temp(3) <= (others => '0');
			ADC_Mem_Temp(4) <= (others => '0');
			ADC_Mem_Temp(5) <= (others => '0');
			ADC_Mem_Temp(6) <= (others => '0');
			ADC_Mem_Temp(7) <= (others => '0');
			ADC_Mem_Temp(8) <= (others => '0');
			ADC_Mem_Temp(9) <= (others => '0');
			ADC_Mem_Temp(10) <= (others => '0');
			ADC_Mem_Temp(11) <= (others => '0');
			ADC_Mem_Temp(12) <= (others => '0');
			ADC_Mem_Temp(13) <= (others => '0');
			ADC_Mem_Temp(14) <= (others => '0');
			ADC_Mem_Temp(15) <= (others => '0');
			
		elsif ADC_Ave_En = '1' then
		
			ADC_Mem_Temp(0) <= ADC_Mem(0) + ADC_Mem_Temp(0);
			ADC_Mem_Temp(1) <= ADC_Mem(1) + ADC_Mem_Temp(1);
			ADC_Mem_Temp(2) <= ADC_Mem(2) + ADC_Mem_Temp(2);
			ADC_Mem_Temp(3) <= ADC_Mem(3) + ADC_Mem_Temp(3);
			ADC_Mem_Temp(4) <= ADC_Mem(4) + ADC_Mem_Temp(4);
			ADC_Mem_Temp(5) <= ADC_Mem(5) + ADC_Mem_Temp(5);
			ADC_Mem_Temp(6) <= ADC_Mem(6) + ADC_Mem_Temp(6);
			ADC_Mem_Temp(7) <= ADC_Mem(7) + ADC_Mem_Temp(7);
			ADC_Mem_Temp(8) <= ADC_Mem(8) + ADC_Mem_Temp(8);
			ADC_Mem_Temp(9) <= ADC_Mem(9) + ADC_Mem_Temp(9);
			ADC_Mem_Temp(10) <= ADC_Mem(10) + ADC_Mem_Temp(10);
			ADC_Mem_Temp(11) <= ADC_Mem(11) + ADC_Mem_Temp(11);
			ADC_Mem_Temp(12) <= ADC_Mem(12) + ADC_Mem_Temp(12);
			ADC_Mem_Temp(13) <= ADC_Mem(13) + ADC_Mem_Temp(13);
			ADC_Mem_Temp(14) <= ADC_Mem(14) + ADC_Mem_Temp(14);
			ADC_Mem_Temp(15) <= ADC_Mem(15) + ADC_Mem_Temp(15);
			
		end if;
	end Process;
	-- End Registers
	
	
		----Process for storing averaged sample data
	ADC_Mem_Ave_Reg: Process
	begin
		wait until clk_SPI'event and clk_SPI = '1';
		if (rst = '0') then
			ADC_Mem_Ave(0) <= (others => '0');
			ADC_Mem_Ave(1) <= (others => '0');
			ADC_Mem_Ave(2) <= (others => '0');
			ADC_Mem_Ave(3) <= (others => '0');
			ADC_Mem_Ave(4) <= (others => '0');
			ADC_Mem_Ave(5) <= (others => '0');
			ADC_Mem_Ave(6) <= (others => '0');
			ADC_Mem_Ave(7) <= (others => '0');
			ADC_Mem_Ave(8) <= (others => '0');
			ADC_Mem_Ave(9) <= (others => '0');
			ADC_Mem_Ave(10) <= (others => '0');
			ADC_Mem_Ave(11) <= (others => '0');
			ADC_Mem_Ave(12) <= (others => '0');
			ADC_Mem_Ave(13) <= (others => '0');
			ADC_Mem_Ave(14) <= (others => '0');
			ADC_Mem_Ave(15) <= (others => '0');
			
		elsif ADC_Ave_Ld = '1' then
			ADC_Mem_Ave(0) <= b"0" & ADC_Mem_Temp(0)(15 downto 1);
			ADC_Mem_Ave(1) <= b"0" & ADC_Mem_Temp(1)(15 downto 1);
			ADC_Mem_Ave(2) <= b"0" & ADC_Mem_Temp(2)(15 downto 1);
			ADC_Mem_Ave(3) <= b"0" & ADC_Mem_Temp(3)(15 downto 1);
			ADC_Mem_Ave(4) <= b"0" & ADC_Mem_Temp(4)(15 downto 1);
			ADC_Mem_Ave(5) <= b"0" & ADC_Mem_Temp(5)(15 downto 1);
			ADC_Mem_Ave(6) <= b"0" & ADC_Mem_Temp(6)(15 downto 1);
			ADC_Mem_Ave(7) <= b"0" & ADC_Mem_Temp(7)(15 downto 1);
			ADC_Mem_Ave(8) <= b"0" & ADC_Mem_Temp(8)(15 downto 1);
			ADC_Mem_Ave(9) <= b"0" & ADC_Mem_Temp(9)(15 downto 1);
			ADC_Mem_Ave(10) <= b"0" & ADC_Mem_Temp(10)(15 downto 1);
			ADC_Mem_Ave(11) <= b"0" & ADC_Mem_Temp(11)(15 downto 1);
			ADC_Mem_Ave(12) <= b"0" & ADC_Mem_Temp(12)(15 downto 1);
			ADC_Mem_Ave(13) <= b"0" & ADC_Mem_Temp(13)(15 downto 1);
			ADC_Mem_Ave(14) <= b"0" & ADC_Mem_Temp(14)(15 downto 1);
			ADC_Mem_Ave(15) <= b"0" & ADC_Mem_Temp(15)(15 downto 1);
			
		end if;
	end Process;
	----End Registers
	
	
	
	---Process for crossing clock domains from SPI to clk to prevent metastability
	ADC_Mem_Ave_Reg_Meta: Process
	begin
		wait until clk'event and clk = '1';
		if (rst = '0') then
			ADC_Mem_Ave_M1(0) <= (others => '0');
			ADC_Mem_Ave_M1(1) <= (others => '0');
			ADC_Mem_Ave_M1(2) <= (others => '0');
			ADC_Mem_Ave_M1(3) <= (others => '0');
			ADC_Mem_Ave_M1(4) <= (others => '0');
			ADC_Mem_Ave_M1(5) <= (others => '0');
			ADC_Mem_Ave_M1(6) <= (others => '0');
			ADC_Mem_Ave_M1(7) <= (others => '0');
			ADC_Mem_Ave_M1(8) <= (others => '0');
			ADC_Mem_Ave_M1(9) <= (others => '0');
			ADC_Mem_Ave_M1(10) <= (others => '0');
			ADC_Mem_Ave_M1(11) <= (others => '0');
			ADC_Mem_Ave_M1(12) <= (others => '0');
			ADC_Mem_Ave_M1(13) <= (others => '0');
			ADC_Mem_Ave_M1(14) <= (others => '0');
			ADC_Mem_Ave_M1(15) <= (others => '0');
			ADC_Mem_Ave_M2(0) <= (others => '0');
			ADC_Mem_Ave_M2(1) <= (others => '0');
			ADC_Mem_Ave_M2(2) <= (others => '0');
			ADC_Mem_Ave_M2(3) <= (others => '0');
			ADC_Mem_Ave_M2(4) <= (others => '0');
			ADC_Mem_Ave_M2(5) <= (others => '0');
			ADC_Mem_Ave_M2(6) <= (others => '0');
			ADC_Mem_Ave_M2(7) <= (others => '0');
			ADC_Mem_Ave_M2(8) <= (others => '0');
			ADC_Mem_Ave_M2(9) <= (others => '0');
			ADC_Mem_Ave_M2(10) <= (others => '0');
			ADC_Mem_Ave_M2(11) <= (others => '0');
			ADC_Mem_Ave_M2(12) <= (others => '0');
			ADC_Mem_Ave_M2(13) <= (others => '0');
			ADC_Mem_Ave_M2(14) <= (others => '0');
			ADC_Mem_Ave_M2(15) <= (others => '0');
			
		else
			ADC_Mem_Ave_M1(0) <= ADC_Mem_Ave(0);
			ADC_Mem_Ave_M1(1) <= ADC_Mem_Ave(1);
			ADC_Mem_Ave_M1(2) <= ADC_Mem_Ave(2);
			ADC_Mem_Ave_M1(3) <= ADC_Mem_Ave(3);
			ADC_Mem_Ave_M1(4) <= ADC_Mem_Ave(4);
			ADC_Mem_Ave_M1(5) <= ADC_Mem_Ave(5);
			ADC_Mem_Ave_M1(6) <= ADC_Mem_Ave(6);
			ADC_Mem_Ave_M1(7) <= ADC_Mem_Ave(7);
			ADC_Mem_Ave_M1(8) <= ADC_Mem_Ave(8);
			ADC_Mem_Ave_M1(9) <= ADC_Mem_Ave(9);
			ADC_Mem_Ave_M1(10) <= ADC_Mem_Ave(10);
			ADC_Mem_Ave_M1(11) <= ADC_Mem_Ave(11);
			ADC_Mem_Ave_M1(12) <= ADC_Mem_Ave(12);
			ADC_Mem_Ave_M1(13) <= ADC_Mem_Ave(13);
			ADC_Mem_Ave_M1(14) <= ADC_Mem_Ave(14);
			ADC_Mem_Ave_M1(15) <= ADC_Mem_Ave(15);
			ADC_Mem_Ave_M2(0) <= ADC_Mem_Ave_M1(0);
			ADC_Mem_Ave_M2(1) <= ADC_Mem_Ave_M1(1);
			ADC_Mem_Ave_M2(2) <= ADC_Mem_Ave_M1(2);
			ADC_Mem_Ave_M2(3) <= ADC_Mem_Ave_M1(3);
			ADC_Mem_Ave_M2(4) <= ADC_Mem_Ave_M1(4);
			ADC_Mem_Ave_M2(5) <= ADC_Mem_Ave_M1(5);
			ADC_Mem_Ave_M2(6) <= ADC_Mem_Ave_M1(6);
			ADC_Mem_Ave_M2(7) <= ADC_Mem_Ave_M1(7);
			ADC_Mem_Ave_M2(8) <= ADC_Mem_Ave_M1(8);
			ADC_Mem_Ave_M2(9) <= ADC_Mem_Ave_M1(9);
			ADC_Mem_Ave_M2(10) <= ADC_Mem_Ave_M1(10);
			ADC_Mem_Ave_M2(11) <= ADC_Mem_Ave_M1(11);
			ADC_Mem_Ave_M2(12) <= ADC_Mem_Ave_M1(12);
			ADC_Mem_Ave_M2(13) <= ADC_Mem_Ave_M1(13);
			ADC_Mem_Ave_M2(14) <= ADC_Mem_Ave_M1(14);
			ADC_Mem_Ave_M2(15) <= ADC_Mem_Ave_M1(15);
		
		end if;
	end process;
	---- End Registers
	
	
----Next state logic for ADC Control Signals
ADC_Ctrl: process(SPI_Dout1_Sync, SPI_Dout2_Sync, NS_ADC_Ctrl, CS_ADC_Ctrl, SPI_Cnt_Out, Prg_Cnt_Out, Setup_CNT_Out, Ave_Cnt_Out, SPI_CNT_Loop_Out)
	begin
	
		----- Define Default States to prevent Latches
		SPI_ROM1_D_SEL  <= 		'0';
		SPI_PS_rst 		<= 		'1';
		SPI_PS_ld_D 	<= 		'0';
		SPI_PS_sh_D 	<= 		'0';
		SPI_Cnt_rst 	<= 		'1';
		SPI_Cnt_INC 	<=		'0';
		Setup_Cnt_rst 	<=		'1';
		Setup_Cnt_INC	<=		'0';
		Prg_Cnt_rst 	<=		'1';
		Prg_Cnt_INC		<=		'0';
		
		--SPI_Din 		<=  	'0';
		SPI_CSn			<=		'1';
		SPI_SP_rst		<=		'1';
		SPI_SP_ld_D		<=		'0';
		
		--ADC_Mem
		ADC_wea			<=		'0';
		ADC_Ave_En		<=		'0';
		Ave_Cnt_rst		<=		'1';
		Ave_Cnt_INC		<=		'0';
		ADC_Temp_rst	<=		'1';
		ADC_Ave_Ld		<=		'0';
		
		--For Setup Loop
		SPI_CNT_Loop_rst<=		'1';
		SPI_Cnt_Loop_INC		<=		'0';




		case CS_ADC_Ctrl is
			when S0 =>
				SPI_Cnt_rst 	<= '0';
				Setup_Cnt_rst 	<= '0';
				Prg_Cnt_rst		<= '0';
				SPI_SP_rst 		<= '0';
				SPI_PS_rst		<= '0';
				ADC_Temp_rst 	<= '0';
				Ave_Cnt_rst		<= '0';
				SPI_CNT_Loop_rst<= '0';
				NS_ADC_Ctrl		<= S1;
				
			--Delay for Alignment
			when S1 =>
				if(SPI_Cnt_Out < Delay) then
					SPI_Cnt_Inc <= '1';
					NS_ADC_Ctrl <= S1;
				else
					SPI_Cnt_rst<= '0';
					NS_ADC_Ctrl <= S2;
				end if;
				
				
			--Begin Dumy Load
			when S2 =>
				SPI_ROM1_D_SEL <= '1';
				SPI_PS_ld_D <= '1';
				SPI_Cnt_rst <= '0';
				NS_ADC_Ctrl <= S3;
				
			when S3 =>
				SPI_ROM1_D_SEL <= '1';
				SPI_PS_ld_D <= '1';
				NS_ADC_Ctrl <= S4;
				
			when S4 => 
				NS_ADC_Ctrl <= S5;
				
			when S5 =>
				SPI_CSn <= '0';
				if (SPI_Cnt_Out < 15) then
					SPI_Cnt_INC <= '1';
					NS_ADC_Ctrl <= S5;
				elsif (Setup_Cnt_Out < 1) then
					Setup_Cnt_INC <= '1';
					SPI_ROM1_D_SEL <= '1';
					NS_ADC_Ctrl <= S2;
				else
					SPI_Cnt_rst <= '0';
					NS_ADC_Ctrl <= S6;
					
				end if;
			--End Dummy Load
			
			
			----Begin ADC Loop
			
			--Delay for beginning of Loop
			when S6 =>
				if(SPI_CNT_Out < 10) then
					SPI_CNT_Inc <= '1';
					NS_ADC_Ctrl <= S6;
				else
					NS_ADC_Ctrl <= S7;
				end if;
			
			--Begin Write Command
			when S7 =>
				SPI_Cnt_rst <= '0';
				SPI_SP_rst <= '0';
				Prg_Cnt_rst <= '0';
				SPI_PS_ld_D <= '1';
				NS_ADC_Ctrl <= S8;
				
			when S8 =>
				SPI_PS_sh_D <= '1';
				--SPI_SP_ld_D <= '1';
				NS_ADC_Ctrl <= S9;
			
			when S9 =>
				SPI_PS_sh_D <= '1';
				SPI_Cnt_INC <= '1';
				SPI_CSn <= '0';
				if (SPI_Cnt_Out < 15) then
					NS_ADC_Ctrl <= S9;
				else
					NS_ADC_Ctrl <= S10;
				end if;
			--End Write Command
			
			when S10 => 
				SPI_Cnt_rst <= '0';
				SPI_SP_rst <= '0';
				NS_ADC_Ctrl <= S11;
			
			--Begin Read Command
			when S11 =>
				NS_ADC_Ctrl <= S12;
				
			when S12 =>
				SPI_Cnt_INC <= '1';
				SPI_CSn <= '0';
				SPI_SP_ld_D <= '1';
				if (SPI_CNT_Out < 15) then
					NS_ADC_Ctrl <= S12;
				else
					NS_ADC_Ctrl <= S13;
				end if;
			
			when S13 =>
				SPI_Cnt_rst <= '0';
				--ADC_wea <= '1';
				NS_ADC_Ctrl <= S14;
				
			when s14 =>
				ADC_wea <= '1';
				NS_ADC_Ctrl <= S15;
				
			when s15 =>
				if(SPI_Cnt_Out < Offset_Chan) then
					SPI_CNT_Inc <= '1';
					NS_ADC_Ctrl <= S15;
				elsif(Prg_Cnt_Out < Chan ) then 
					Prg_Cnt_INC <= '1';
					NS_ADC_Ctrl <= S10;
				else
					SPI_Cnt_rst <= '0';
					Prg_Cnt_rst <= '0';
					Setup_Cnt_rst <= '0';
					NS_ADC_Ctrl <= S16;
				end if;
				
			when S16 =>
				if (Ave_Cnt_Out < (Sample_Size - 1)) then
					NS_ADC_Ctrl <= S18;
				else 
					NS_ADC_Ctrl <= S17;
				end if;
				ADC_Ave_En <= '1';
				Ave_Cnt_INC <= '1';
			
			when S17 =>
				ADC_Ave_Ld <= '1';
				ADC_Temp_rst <= '0';
				Ave_Cnt_rst <= '0';
				SPI_Cnt_Inc <= '1';
				NS_ADC_Ctrl <= S18;
				
			when S18 =>
				if(SPI_Cnt_Out < Offset_Set) then
					SPI_CNT_Inc <= '1';
					NS_ADC_Ctrl <= S18;
				else
					SPI_Cnt_rst <= '0';
					Prg_Cnt_rst <= '0';
					if (SPI_CNT_Loop_Out < 1000) then
						SPI_CNT_Loop_INC <= '1';
						NS_ADC_Ctrl <= S10;
					else
						NS_ADC_Ctrl <= S0;
					end if;
				end if;
				
			when others =>
				NS_ADC_Ctrl <= S0;
				
			end case;
	end process;
	----Next State Logic for ADC Control Signals
		
	
	
	
	
	
	
	
	
	
	
	
	----Next State Logic for Bus Interface
	NSL_Bus: process(CS_Bus_Ctrl, Bus_Cnt_Out, Bus_Int1_Busy, Mem_Addr_Cnt_Out, ADC_Mem_Ave_M2)
	Begin
	
		----Default States to remove Latches
		Bus_Int1_AddrIn <= (others => '0');
		Bus_Int1_RE <= '0';
		Bus_Int1_DataIn <= (others => '0');
		Bus_Int1_WE <= '0';
		Bus_Cnt_rst <= '1';
		Bus_Cnt_Inc <= '0';
		Mem_Addr_Cnt_rst <= '1';
		Mem_Addr_Cnt_INC <= '0';
		
		
		case CS_Bus_Ctrl is
			when S0 => 
					Bus_Cnt_rst <= '0';
					Mem_Addr_Cnt_rst <= '0';
					NS_Bus_Ctrl <= S1;
					
			--Write Measurement Data to the Bus
			when S1 => 
					if(Bus_Cnt_Out < 4002) then
						NS_Bus_Ctrl <= S1;
					else
						NS_Bus_Ctrl <= S2;
					end if;
					Bus_Cnt_Inc <= '1';
					
			when S2 =>
					if(Bus_Int1_Busy = '1') then
						NS_Bus_Ctrl <= S2;
					else
						NS_Bus_Ctrl <= S3;
					end if;
					
			when S3 =>
					if(Mem_Addr_Cnt_Out < 15) then
						NS_Bus_Ctrl <= S2;
					else
						NS_Bus_Ctrl <= S0;
					end if;
					
					--ADC map
					if(Mem_Addr_Cnt_Out = 0) then Bus_Int1_AddrIn <= Addr_ADC0; end if;
					if(Mem_Addr_Cnt_Out = 1) then Bus_Int1_AddrIn <= Addr_ADC1; end if;
					if(Mem_Addr_Cnt_Out = 2) then Bus_Int1_AddrIn <= Addr_ADC2; end if;
					if(Mem_Addr_Cnt_Out = 3) then Bus_Int1_AddrIn <= Addr_ADC3; end if;
					if(Mem_Addr_Cnt_Out = 4) then Bus_Int1_AddrIn <= Addr_ADC4; end if;
					if(Mem_Addr_Cnt_Out = 5) then Bus_Int1_AddrIn <= Addr_ADC5; end if;
					if(Mem_Addr_Cnt_Out = 6) then Bus_Int1_AddrIn <= Addr_ADC6; end if;
					if(Mem_Addr_Cnt_Out = 7) then Bus_Int1_AddrIn <= Addr_ADC7; end if;
					if(Mem_Addr_Cnt_Out = 8) then Bus_Int1_AddrIn <= Addr_ADC8; end if;
					if(Mem_Addr_Cnt_Out = 9) then Bus_Int1_AddrIn <= Addr_ADC9; end if;
					if(Mem_Addr_Cnt_Out = 10) then Bus_Int1_AddrIn <= Addr_ADC10; end if;
					if(Mem_Addr_Cnt_Out = 11) then Bus_Int1_AddrIn <= Addr_ADC11; end if;
					if(Mem_Addr_Cnt_Out = 12) then Bus_Int1_AddrIn <= Addr_ADC12; end if;
					if(Mem_Addr_Cnt_Out = 13) then Bus_Int1_AddrIn <= Addr_ADC13; end if;
					if(Mem_Addr_Cnt_Out = 14) then Bus_Int1_AddrIn <= Addr_ADC14; end if;
					if(Mem_Addr_Cnt_Out = 15) then Bus_Int1_AddrIn <= Addr_ADC15; end if;
					
					Bus_Int1_DataIn <= ADC_Mem_Ave_M2(conv_integer(Mem_Addr_Cnt_Out(3 downto 0))); -- set data
					Mem_Addr_Cnt_INC <= '1';
					Bus_Int1_WE <= '1';
					
					
					
					
				when others =>
					NS_Bus_Ctrl <= S0;
					
		end case;
	end process;
	----END Next State Logic for Bus Interface




	-- Sync Process for FSMs
	sync_ADC: Process
	Begin
		wait until clk_SPI'event and clk_SPI = '1';
		if rst = '0' then
			CS_ADC_Ctrl <= S0;
		else
			CS_ADC_Ctrl <= NS_ADC_Ctrl;
		end if;
	end process;
	
	-- Sync process for FSMs
	sync_Bus: Process
	Begin
		wait until clk'event and clk = '1';
		if rst = '0' then
			CS_Bus_Ctrl <= S0;
		else
			CS_Bus_Ctrl <= NS_Bus_Ctrl;
		end if;
	end process;
	
	
	
	
	--- Synch for Dout Signals
	sync_SPI: Process
	Begin
		wait until clk_SPI'event and clk_SPI = '0';
		if rst = '0' then
			SPI_Dout1_Sync <= '0';
		else
			SPI_Dout1_Sync <= SPI_Dout;
		end if;
	end process;
	
	
	
	
	-- Clock Divider for SPI_Sclk
	Clk_Div_Top: Process
	Begin
		wait until clk'event and clk = '1';
			clk_temp2 <= clk_temp2+1;
			--clk_SPI <= clk_temp2(3);
			clk_SPI <= clk_temp2(2);
			--clk_SPI <= not(clk_SPI);
	end process;
	
end Behavioral;
			
			
			
	
			
			
			
			
			
			
			
